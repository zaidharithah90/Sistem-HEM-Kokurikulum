(function(){
  var text = {
    sekolah: "<strong>Peranan jabatan:</strong> Sekolah memilih atlet melalui Hari Sukan dan latihan. Jabatan menyediakan garis panduan pemilihan dan memastikan dasar 1Murid 1Sukan dilaksanakan.",
    mssd: "<strong>Peranan jabatan:</strong> Pejabat Pendidikan Daerah menganjurkan kejohanan MSSD. Jabatan menetapkan tarikh, peraturan dan kelayakan supaya semua daerah seragam.",
    mssn: "<strong>Peranan jabatan:</strong> Jabatan menganjurkan sendiri kejohanan MSSN, melantik pegawai teknik dan memilih atlet terbaik untuk kontinjen negeri.",
    mssm: "<strong>Peranan jabatan:</strong> Jabatan menghantar dan mengurus kontinjen negeri ke kejohanan MSSM, termasuk latihan pusat, pengangkutan, penginapan dan kebajikan atlet."
  };
  var steps = document.querySelectorAll('.step');
  var out = document.getElementById('flow-text');
  steps.forEach(function(btn){
    btn.addEventListener('click', function(){
      steps.forEach(function(b){ b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'); });
      out.innerHTML = text[btn.getAttribute('data-key')];
    });
  });
})();
