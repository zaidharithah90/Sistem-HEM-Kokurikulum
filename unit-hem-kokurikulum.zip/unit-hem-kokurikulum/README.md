# Unit Hal Ehwal Murid dan Unit Kokurikulum

Laman web statik untuk Unit Hal Ehwal Murid (HEM) dan Unit Kokurikulum, Sektor Pembangunan Murid, Jabatan Pendidikan Negeri.

## Struktur folder

```
unit-hem-kokurikulum/
├── index.html      ← kandungan laman (teks, bahagian, menu)
├── css/
│   └── style.css   ← rupa laman (warna, fon, susun atur)
├── js/
│   └── script.js   ← interaktiviti (butang laluan pertandingan MSSD/MSSN/MSSM)
└── README.md       ← fail ini
```

## Perkara yang perlu diisi

Cari teks dalam kurungan `[ ]` di `index.html` dan gantikan dengan maklumat sebenar:

- `[Nama Negeri]`: nama negeri jabatan
- `[Nama]`: nama pegawai dalam carta organisasi
- `[No. telefon]`, `[alamat e-mel]`, `[Alamat penuh jabatan]`
- `[Bilangan]`: bilangan pegawai
- Piagam pelanggan

Tip VS Code: tekan `Ctrl + Shift + F` (Mac: `Cmd + Shift + F`) dan cari `[` untuk jumpa semua ruang kosong.

## Melihat laman di komputer

Klik dua kali `index.html` untuk membukanya di pelayar web.

Untuk pratonton yang dikemas kini secara automatik setiap kali anda simpan, pasang sambungan **Live Server** di VS Code, kemudian klik kanan `index.html` → **Open with Live Server**.

## Menerbitkan laman (VS Code → GitHub → Vercel)

### Kali pertama

1. Buka folder ini di VS Code (**File → Open Folder**).
2. Klik ikon **Source Control** di bar sisi kiri → **Publish to GitHub** → pilih **Public**.
3. Pergi ke [vercel.com](https://vercel.com), log masuk dengan GitHub.
4. **Add New… → Project** → pilih repository `unit-hem-kokurikulum` → **Import** → **Deploy**.
5. Laman anda akan berada di `unit-hem-kokurikulum.vercel.app` (atau nama yang hampir sama).

### Setiap kali mengemas kini

1. Edit fail dan simpan (`Ctrl + S`).
2. Di **Source Control**, tulis mesej ringkas (contoh: `Kemas kini nama pegawai`) dan klik **Commit**.
3. Klik **Sync Changes**.
4. Vercel akan mengemas kini laman secara automatik dalam masa kira-kira 30 saat.
